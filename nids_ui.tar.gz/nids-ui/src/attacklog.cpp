#include "attacklog.h"
#include "ui_attacklog.h"
#include <QScrollArea>
#include <QFile>
#include <QTextStream>

void errorWindow(const QString windowName, const QString context);

attacklog::attacklog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::attacklog)
{
    this -> setAutoFillBackground(true);
    QPalette p = this -> palette();
    QPixmap pix(":/photo.png");
    p.setBrush(QPalette::Window, QBrush(pix));
    this -> setPalette(p);
    ui->setupUi(this);
    int x = 200;
    int y = 200;
    move(x,y);
    QFile file("attack_log.txt");
    if (file.open(QIODevice::ReadOnly)) {
        QTextStream in(&file);
        QString text = in.readAll();
        ui->label->setText(text);
        file.close();
    }
    else {
        ui->label->setText("无法打开文件");
        errorWindow("错误", "打开文件失败");
    }

    // 设置QLabel属性

    ui->scrollArea->setWidget(ui->label);
    ui->scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarPolicy::ScrollBarAlwaysOn);
}

attacklog::~attacklog()
{
    delete ui;
}
