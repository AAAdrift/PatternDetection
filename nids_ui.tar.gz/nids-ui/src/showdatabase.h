#ifndef SHOWDATABASE_H
#define SHOWDATABASE_H

#include <QWidget>

namespace Ui {
class showdatabase;
}

class showdatabase : public QWidget
{
    Q_OBJECT

public:
    explicit showdatabase(QWidget *parent = nullptr);
    ~showdatabase();

private:
    Ui::showdatabase *ui;
};

#endif // SHOWDATABASE_H
