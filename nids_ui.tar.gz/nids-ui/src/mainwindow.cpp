#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "help.h"
#include "log.h"
#include "menu.h"
#include <fstream>

int rules=0;
int al=0;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("初始界面");
    //设置按钮字体大小
    ui->pushButton_3->setFont(QFont("宋体"));
    //设置背景图
    this -> setAutoFillBackground(true);
    QPalette p = this -> palette();
    QPixmap pix(":/photo.png");
    p.setBrush(QPalette::Window, QBrush(pix));
    this -> setPalette(p);
    int x = 200;
    int y = 200;
    move(x,y);
    ui->comboBox->insertItem(0, "请选择一个选项");
    ui->comboBox->setCurrentIndex(0);

    // 确保当用户开始选择时，提示信息可以被移除
    connect(ui->comboBox, QOverload<int>::of(&QComboBox::activated), [=](int index){
        if (ui->comboBox->itemText(0) == "请选择一个选项") {
            ui->comboBox->removeItem(0);
        }
    });
    ui->comboBox_2->insertItem(0, "请选择一个选项");
    ui->comboBox_2->setCurrentIndex(0);

    // 确保当用户开始选择时，提示信息可以被移除
    connect(ui->comboBox_2, QOverload<int>::of(&QComboBox::activated), [=](int index){
        if (ui->comboBox_2->itemText(0) == "请选择一个选项") {
            ui->comboBox_2->removeItem(0);
        }
    });

}

MainWindow::~MainWindow()
{
    delete ui;
}

//打开登录界面
void MainWindow::on_pushButton_2_clicked()
{
    if(rules!=2){
        Log *configWindow = new Log;
        configWindow -> show();
    }
    else{

        // 打开或创建日志文件
        FILE *logFile = fopen("attack_log.txt", "a"); // 使用 "a" 模式来追加写入
        if (logFile == NULL) {
            perror("Error opening log file");
            return;
        }

        // 打开或创建日志文件
        FILE *alertFile = fopen("attack_alert.txt", "w");
        if (alertFile == NULL) {
            perror("Error opening log file");
            return;
        }

        fclose(logFile);
        fclose(alertFile);

        Menu *config = new Menu;
        config -> show();
    }

}

//打开帮助界面
void MainWindow::on_pushButton_3_clicked()
{
    Help *configWindow = new Help;
    configWindow -> show();
}



void MainWindow::on_comboBox_2_currentIndexChanged()
{
    al = ui->comboBox_2->currentIndex();
}


void MainWindow::on_comboBox_currentIndexChanged()
{
    rules = ui->comboBox->currentIndex();
}

