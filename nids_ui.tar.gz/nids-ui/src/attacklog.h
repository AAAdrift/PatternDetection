#ifndef ATTACKLOG_H
#define ATTACKLOG_H

#include <QWidget>

namespace Ui {
class attacklog;
}

class attacklog : public QWidget
{
    Q_OBJECT

public:
    explicit attacklog(QWidget *parent = nullptr);
    ~attacklog();

private:
    Ui::attacklog *ui;
};

#endif // ATTACKLOG_H
