#include "log.h"
#include "ui_log.h"
#include <functional>
#include <fstream>
#include <map>
#include "auxiliary.h"
#include "menu.h"

using namespace std;

bool flag = false;

void errorWindow(const QString windowName, const QString context);

string id;
string password;

Log::Log(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Log)
{
    this -> setAutoFillBackground(true);
    QPalette p = this -> palette();
    QPixmap pix(":/photo.png");
    p.setBrush(QPalette::Window, QBrush(pix));
    this -> setPalette(p);

    ui->setupUi(this);

    //设置文本字体
    ui->pushButton->setFont(QFont("宋体", 18));
    //将密码行改为隐式文本
    ui->lineEdit_2->setEchoMode(QLineEdit::Password);
    int x = 200;
    int y = 200;
    move(x,y);
}

Log::~Log()
{
    delete ui;
}


void Log::on_pushButton_clicked()
{
    //接受用户名和密码的输入
    QString qid, qpassword;
    qid = ui -> lineEdit -> text();
    qpassword = ui -> lineEdit_2 -> text();
    id = qid.toStdString();
    password = qpassword.toStdString();

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setDatabaseName("ids");
    db.setUserName(id.c_str());
    db.setPassword(password.c_str());

    if (!db.open()) {
        errorWindow("登陆失败", "用户名或密码错误，无法连接数据库");
        return;
    }
    db.close();

    // 打开或创建日志文件
    FILE *logFile = fopen("attack_log.txt", "a"); // 使用 "a" 模式来追加写入
    if (logFile == NULL) {
        perror("Error opening log file");
        return;
    }

    // 打开或创建日志文件
    FILE *alertFile = fopen("attack_alert.txt", "w");
    if (alertFile == NULL) {
        perror("Error opening log file");
        return;
    }

    fclose(logFile);
    fclose(alertFile);


    Menu *config = new Menu;
    config -> show();
}


void Log::on_checkBox_stateChanged(int arg1)
{
    if(!flag)
    {
        ui -> lineEdit_2 -> setEchoMode(QLineEdit::Normal);
    }
    else ui -> lineEdit_2 -> setEchoMode(QLineEdit::Password);
    flag = !flag;
}

