#include "auxiliary.h"
#include "ui_auxiliary.h"
#include <fstream>
#include <cstring>
#include <QLabel>

using namespace std;

Auxiliary::Auxiliary(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Auxiliary)
{
    this -> setAutoFillBackground(true);
    QPalette p = this -> palette();
    QPixmap pix(":/photo.png");
    p.setBrush(QPalette::Window, QBrush(pix));
    this -> setPalette(p);

    ui->setupUi(this);
}

Auxiliary::~Auxiliary()
{
    delete ui;
}



void errorWindow(const QString windowName, const QString context) {
    QWidget* Test;
    Test = new QWidget;
    Test->setWindowTitle(windowName);
    Test->resize(250, 100);
    Test->show();
    QLabel* ttest = new QLabel(Test);
    ttest->setAlignment(Qt::AlignCenter);
    ttest->resize(Test->width(), Test->height());
    ttest->setText(context);
    ttest->show();
}
