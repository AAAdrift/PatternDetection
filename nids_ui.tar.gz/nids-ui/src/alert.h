#ifndef ALERT_H
#define ALERT_H

#include <QDialog>
#include <QFileSystemWatcher>

namespace Ui {
class Alert;
}

class Alert : public QDialog
{
    Q_OBJECT

public:
    explicit Alert(const QString &filePath, QWidget *parent = nullptr);
    ~Alert();

private slots:
    void updateTextFileContent(); // 更新文本文件内容的槽函数
    void on_pushButton_clicked();

private:
    Ui::Alert *ui;
    QString filePath; // 监视的文件路径
    QFileSystemWatcher *watcher; // 文件监视器
};

#endif // ALERT_H
