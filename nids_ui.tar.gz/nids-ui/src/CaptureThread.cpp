#include "menu.h"
#include "ui_menu.h"
#include "auxiliary.h"
#include "CaptureThread.h"
#include <pcap.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdarg.h>
#include "acsm.h"
#include <sys/time.h>
#include <mysql/mysql.h>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <limits.h>

#include <QThread>



typedef struct { //ip头格式
    u_char version:4;
    u_char header_len:4;
    u_char tos:8;
    u_int16_t total_len:16;
    u_int16_t ident:16;
    u_char flags:8;
    u_char fragment:8;
    u_char ttl:8;
    u_char proto:8;
    u_int16_t checksum;
    u_char sourceIP[4];
    u_char destIP[4];
}IPHEADER;

// 定义用于保存重组后数据包的结构体
typedef struct POnepOnepacket {
    u_char src_ip[4];
    u_char dest_ip[4];
    char *packetcontent;
    int contentlen;
    int is_last_frag;
    int offset;
    u_int16_t id;
    int totallen;
    char src[10];
    char des[10];
} POnepOnepacket;

typedef struct Packetinfo2{
    u_char src_ip[4];
    u_char dest_ip[4];
    char *packetcontent;
    int contentlen;
    char src[10];
    char des[10];
}PACKETINFO2;

#define MAX_FRAG 1024
extern POnepOnepacket packets[MAX_FRAG];
extern int frag_num;


typedef struct ATTACKPATTERN{
    char attackdes[256];
    char patterncontent[5000];
    int patternlen;
    char src[10];
    char des[10];
    struct ATTACKPATTERN *next;
}ATTACKPATTERN;

extern ATTACKPATTERN* pPatternHeader;//全局变量，保存攻击模式链表头
extern int minpattern_len;    //最短模式的长度

extern pcap_t *phandle;

extern int count_alert;
QMutex mutex;


extern int **suffix;
extern bool **prefix;
extern int **modelStrIndex;
extern acsm_context_t  *ctx;

match_result_t acsm_search(acsm_context_t *ctx, u_char *string, size_t len);

extern int al;
extern int rules;

bool cvt_path(char *src, char *dest) {
    char *pos = strchr(src, '/');
    if(pos == NULL) return false;

}
int hex_char_to_int(char c) {
    if (c >= '0' && c <=  '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c -'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
}
char *url_decode(char *src_string) {
    if(strlen(src_string) < 3) return src_string;

    char *ret = (char *)malloc(strlen(src_string) + 1);
    char *j = ret;
    for(int i = 0; i < (strlen(src_string) - 2); ++i) {
        if(src_string[i] == '%') {
            *j = (char)((hex_char_to_int(src_string[i + 1]) << 4) | hex_char_to_int(src_string[i + 2]));
            j++;
            i += 2;
        } else {
            *j = src_string[i];
            j++;
        }
    }
    for(int i = strlen(src_string) - 2; i < strlen(src_string); ++i) {
        *j = src_string[i];
        j++;
    }
    *j = '\0';
    return ret;
}

// 重组数据包
int reassemble_packet(POnepOnepacket *pkt, u_int16_t id) {
    int total_length = 0;
    char *content = NULL;
    // 找到所有ID匹配的分片并重组
    for (size_t i = 0; i <= frag_num; ++i) {
        if (packets[i].id == id && packets[i].packetcontent != NULL) {
            total_length += strlen(packets[i].packetcontent);
            // 填充POnepOnepacket结构体
            for(int j = 0; j <= 3; ++ j) {
                pkt->src_ip[j] = packets[i].src_ip[j];
                pkt->dest_ip[j] = packets[i].dest_ip[j];
            }
        }
    }

    if(total_length <= 0) return 0;
    content = (char *)malloc(total_length + 1);
    if (content == NULL) {
        printf("Memory allocation failed\n");
        return 0;
    }
    char *j = content;
    for (size_t i = 0; i <= frag_num; ++i) {
        if (packets[i].id == id && packets[i].packetcontent != NULL) {
            memcpy(j, packets[i].packetcontent, strlen(packets[i].packetcontent));
            j +=  strlen(packets[i].packetcontent);
        }
    }
    pkt->totallen = total_length;
    pkt->contentlen = strlen(content);
    pkt->packetcontent = (char *)malloc(strlen(content) + 1);
    memcpy(pkt->packetcontent, content, strlen(content));
    frag_num = 0;

    return 1;
}

void output_alert_0(ATTACKPATTERN *pOnepattern,POnepOnepacket *pOnepacket,const struct pcap_pkthdr *header)
{
    // 日志文件路径
    const char *logFilePath = "attack_log.txt";

    // 打开或创建日志文件
    FILE *logFile = fopen(logFilePath, "a"); // 使用 "a" 模式来追加写入
    if (logFile == NULL) {
        perror("Error opening log file");
        return;
    }

    // 日志文件路径
    const char *alertFilePath = "attack_alert.txt";

    // 打开或创建日志文件
    FILE *alertFile = fopen(alertFilePath, "w");
    if (alertFile == NULL) {
        perror("Error opening log file");
        return;
    }

    // 写入日志文件

    fprintf(logFile, "[Time: %lld.%lld]\n",header->ts.tv_sec, header->ts.tv_usec);
    fprintf(logFile, "[%s]\t", pOnepattern->attackdes);
    fprintf(logFile, "%u.%u.%u.%u ==> ", pOnepacket->src_ip[0], pOnepacket->src_ip[1], pOnepacket->src_ip[2], pOnepacket->src_ip[3]);
    fprintf(logFile, "%u.%u.%u.%u\n", pOnepacket->dest_ip[0], pOnepacket->dest_ip[1], pOnepacket->dest_ip[2], pOnepacket->dest_ip[3]);
    fprintf(logFile, "%s\n\n",pOnepacket->packetcontent);

    fprintf(alertFile, "Intrusion Detected:\nType:  %s\n", pOnepattern->attackdes);
    fprintf(alertFile, "Time: %lld.%lld\n",header->ts.tv_sec, header->ts.tv_usec);
    fprintf(alertFile, "%u.%u.%u.%u ==> ", pOnepacket->src_ip[0], pOnepacket->src_ip[1], pOnepacket->src_ip[2], pOnepacket->src_ip[3]);
    fprintf(alertFile, "%u.%u.%u.%u\n", pOnepacket->dest_ip[0], pOnepacket->dest_ip[1], pOnepacket->dest_ip[2], pOnepacket->dest_ip[3]);

    printf("\033[1;34m");
    printf("Intrusion Detected:\n     Type:  %s   ", pOnepattern->attackdes);
    printf("%d.%d.%d.%d ==> ",pOnepacket->src_ip[0],pOnepacket->src_ip[1],pOnepacket->src_ip[2],pOnepacket->src_ip[3]);
    printf("%d.%d.%d.%d\n",pOnepacket->dest_ip[0],pOnepacket->dest_ip[1],pOnepacket->dest_ip[2],pOnepacket->dest_ip[3]);
    printf("\033[0m");

    // 关闭日志文件
    fclose(logFile);
    fclose(alertFile);
}


//返回好后缀移动的次数,index为坏字符位置-其后面就是好后缀，size为str大小
int getGsMove(int suffix[], bool prefix[], int index, int size)
{
    int len = size - index - 1;//好字符的长度，因为index为坏字符位置，所以要多减1
    if(len==0) return 1;
    if (suffix[len] != -1)//当前len长度的后缀坏字符串前边有匹配的字符
    {
        return index + 1 - suffix[len];//后移位数 = 好后缀的位置(index + 1) - 搜索词中的上一次出现位置
    }

    //index为坏字符，index+1为好后缀，index+2为子好后缀
    for (int i = index + 2; i < size; i++)
    {
        if (prefix[size - i])//因为prefix从1开始
            return i;//移动当前位置离前缀位置，acba-对应a移动3
    }

    return size;

}

int max(int a, int b) {
    return (a > b) ? a : b;
}
int badChar(char badChr,int badCharIndex,int modelStrIndex[],int modelStrLen) {
        //查看坏字符在匹配串中出现的位置
        if (badChr>=0 && badChr<=255 && modelStrIndex[badChr] > -1) {
            //出现过

            return badCharIndex - modelStrIndex[badChr];
        }
        return badCharIndex + 1;
    }





int matchpattern(ATTACKPATTERN *pOnepattern, POnepOnepacket *pOnepacket){
    int leftlen;
    char *leftcontent;

    leftcontent = pOnepacket -> packetcontent;
    leftlen = strlen(leftcontent);//pOnepacket-> contentlen;

    while(leftlen >= pOnepattern->patternlen){
        if (strncmp(leftcontent,pOnepattern->patterncontent,pOnepattern->patternlen) == 0) {
            return 1;
        }

        leftlen --;
        leftcontent ++;
    }
    return 0;
}


int matchpattern_BM(ATTACKPATTERN *pOnepattern, POnepOnepacket *pOnepacket, int i){
    int *patternIndex = modelStrIndex[i];
    int m = pOnepattern->patternlen;
    char *leftcontent = pOnepacket -> packetcontent;
    char *pcontent = pOnepattern -> patterncontent;
    int *suffix_i = suffix[i];
    bool *prefix_i = prefix[i];

    int leftlen;
    leftlen = pOnepacket-> contentlen;
    if(leftlen<=0)return 0;
    int start=0;
    char badChr = '\0';
    int n=m-1;
    while(start+m-1<leftlen){
        while(n>=0){
            if (leftcontent[start+n] != pcontent[n]){
                badChr = leftcontent[start+n];
                break;
            }
            n--;
        }
        if(n==-1){
            return 1;
        }
        int bad_mv = badChar(badChr,n,patternIndex,m);
        int good_mv = getGsMove(suffix_i, prefix_i, n, m);
        int mv=max(bad_mv,good_mv);
        start=start+mv;
        n = pOnepattern->patternlen-1;
    }

    return 0;


}

int matchpattern_AC(int pattern_len, POnepOnepacket *pOnepacket, const struct pcap_pkthdr *header){
    ATTACKPATTERN *pOnepattern = pPatternHeader;
    char *text = pOnepacket -> packetcontent;
    char text_len = pOnepacket ->contentlen;
    match_result_t matches = acsm_search(ctx, (u_char *)text, acsm_strlen(text));
    int match_full = matches.count;
    if (matches.count > 0) {
        for (size_t i = 0; i < matches.count; ++i) {
            int count = matches.patterns[i];
            pOnepattern = pPatternHeader;
            while(pOnepattern != NULL && count!=0){
            pOnepattern = pOnepattern->next;
            count--;
            }
            int max_len=max(strlen(pOnepattern->src),strlen(pOnepacket->src));
            //添加对端口的判断
            if(((strncmp(pOnepattern->src,"any",3)==0)||(strncmp(pOnepattern->src,pOnepacket->src,max_len)==0))&&((strncmp(pOnepattern->des,"any",3)==0)||(strncmp(pOnepattern->des,pOnepacket->des,max_len)==0)))
            {
                mutex.lock(); // 请求锁
                output_alert_0(pOnepattern, pOnepacket, header);
                count_alert++;
                mutex.unlock(); // 释放锁
            }
            else {
                match_full--;
            }
        }
    }
    if (match_full > 0) return 1;
    else {
        return 0;
    }

}


// libpcap回调函数
void pcap_callback(u_char *user, const struct pcap_pkthdr *header, const u_char *pkt_data) {

    IPHEADER *ip_header;
    ATTACKPATTERN *pOnepattern;
    bzero(&packets[frag_num],sizeof(POnepOnepacket));

    if(header->len >= 14)
        ip_header=(IPHEADER*)(pkt_data+14);
    else
        return;
    if(ip_header->proto == 6){

        packets[frag_num].totallen = ip_header->total_len;
        packets[frag_num].contentlen = ip_header->total_len - 20 - 20;
        if (packets[frag_num].contentlen < minpattern_len)
            return;
        packets[frag_num].packetcontent = (char *)(pkt_data + 14 + 20 + 20);

        memcpy(packets[frag_num].src_ip,ip_header->sourceIP,4);
        memcpy(packets[frag_num].dest_ip,ip_header->destIP,4);

        packets[frag_num].offset = ip_header->flags & 0x20;
        packets[frag_num].is_last_frag = (packets[frag_num].offset == 0);
        packets[frag_num].id = ip_header->ident;


if(packets[frag_num].is_last_frag) {
            POnepOnepacket finalPack;
            if(!reassemble_packet(&finalPack, packets[frag_num].id)) return;
                        //解码
                        char *tmp = url_decode(finalPack.packetcontent);
                        memcpy(finalPack.packetcontent, tmp, strlen(tmp));
                        finalPack.packetcontent[strlen(tmp) + 1] = '\0';
                        finalPack.contentlen = strlen(finalPack.packetcontent);
                        finalPack.totallen = finalPack.contentlen + 40;
            if(al==1){
                //暴力匹配
                ATTACKPATTERN *pOnepattern = pPatternHeader;
                while(pOnepattern != NULL){
                    if (matchpattern(pOnepattern, &finalPack)){
                        mutex.lock(); // 请求锁
                        output_alert_0(pOnepattern, &finalPack, header);
                        count_alert++;
                        mutex.unlock(); // 释放锁
                    }
                    pOnepattern = pOnepattern->next;
                }
            }else if(al==3||(al==0 && rules==2)){

                //BM算法匹配
                 struct ip * ip_header2=(struct ip *)(pkt_data+14);

                 struct tcphdr *tcp_header = (struct tcphdr *)(pkt_data + 14 + (ip_header2->ip_hl * 4));
                 sprintf(finalPack.src, "%d", ntohs(tcp_header->th_sport));
                 sprintf(finalPack.des, "%d", ntohs(tcp_header->th_dport));


                 ATTACKPATTERN *pOnepattern1 = pPatternHeader;
                 int i=0;
                 while(pOnepattern1 != NULL){
                     if (matchpattern_BM(pOnepattern1, &finalPack, i)){
                         int max_len = max(strlen(pOnepattern1->src), strlen(finalPack.src));
                         if(((strncmp(pOnepattern1->src, "any", 3) == 0) ||
                         (strncmp(pOnepattern1->src, finalPack.src, max_len) == 0)) &&
                         ((strncmp(pOnepattern1->des, "any", 3) == 0) ||
                         (strncmp(pOnepattern1->des, finalPack.des, max_len) == 0))){
                             mutex.lock(); // 请求锁
                             output_alert_0(pOnepattern1, &finalPack, header);
                             count_alert++;
                             mutex.unlock(); // 释放锁
                         }

                     }
                     pOnepattern1 = pOnepattern1->next;
                     i++;
                 }
            }else{

                //AC自动机
                 struct ip * ip_header2=(struct ip *)(pkt_data+14);

                 struct tcphdr *tcp_header = (struct tcphdr *)(pkt_data + 14 + (ip_header2->ip_hl * 4));
                 sprintf(finalPack.src, "%d", ntohs(tcp_header->th_sport));
                 sprintf(finalPack.des, "%d", ntohs(tcp_header->th_dport));
                 ATTACKPATTERN *pOnepattern = pPatternHeader;
                 int pattern_len2 = 0;
                 while(pOnepattern != NULL){
                     pattern_len2++;
                     pOnepattern = pOnepattern->next;
                 }
                 pOnepattern = pPatternHeader;
                 if(pOnepattern != NULL){
                     int match2=matchpattern_AC(pattern_len2, &finalPack, header);
                 }

            }
        }

    }
    frag_num ++;
        if (frag_num == MAX_FRAG) frag_num = 0;
}


CaptureThread::CaptureThread(QObject *parent) : QThread(parent){}
void CaptureThread::run(){
    char *device;
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_t *phandle;
    bpf_u_int32 ipaddress, ipmask;
    struct bpf_program fcode;
    if((device = pcap_lookupdev(errbuf)) == NULL) exit(0);                 //获得可用的网络设备名.
    if(pcap_lookupnet(device,&ipaddress,&ipmask,errbuf)==-1)    //获得ip和子网掩码
    exit(0);
    else {
        char net[INET_ADDRSTRLEN],mask[INET_ADDRSTRLEN];
        if(inet_ntop(AF_INET,&ipaddress,net,sizeof(net)) == NULL)
            exit(0);
      else
            if(inet_ntop(AF_INET,&ipmask,mask,sizeof(mask)) == NULL)	exit(0);
        }
    phandle = pcap_open_live(device,200,1,500,errbuf);                    //打开设备
    if(phandle == NULL)
        exit(0);

    if(pcap_compile(phandle,&fcode,"ip and tcp",0,ipmask) == -1) exit(0);         //设置过滤器，只捕获ip&tcp报头的包

    if(pcap_setfilter(phandle,&fcode) == -1)
        exit(0);
     pcap_loop(phandle, -1, pcap_callback, NULL);
}
