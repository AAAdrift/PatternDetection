#ifndef MENU_H
#define MENU_H

#include <QWidget>
#include <QtSql>
#include <CaptureThread.h>
#include <QMessageBox>


namespace Ui {
class Menu;
}

class Menu : public QWidget
{
    Q_OBJECT

public:
    explicit Menu(QWidget *parent = nullptr);
    ~Menu();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void slot1();

    void on_pushButton_clicked();

    void captureFinished();

    void startCapture();

    void showMessage(const QString &message) {
            QMessageBox::information(this, "Message", message);
        }


private:
    Ui::Menu *ui;
    CaptureThread *captureThread;
};

#endif // MENU_H
