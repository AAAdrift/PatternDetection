#ifndef SHOWPATTERN_H
#define SHOWPATTERN_H

#include <QWidget>

namespace Ui {
class showpattern;
}

class showpattern : public QWidget
{
    Q_OBJECT

public:
    explicit showpattern(QWidget *parent = nullptr);
    ~showpattern();

private:
    Ui::showpattern *ui;
};

#endif // SHOWPATTERN_H
