#include "showdatabase.h"
#include "ui_showdatabase.h"
#include <QSqlDatabase>
#include <QSqlTableModel>
#include <QTableView>
#include <string>
using namespace std;

extern string id;
extern string password;
void errorWindow(const QString windowName, const QString context);

showdatabase::showdatabase(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::showdatabase)
{
    this -> setAutoFillBackground(true);
    QPalette p = this -> palette();
    QPixmap pix(":/photo.png");
    p.setBrush(QPalette::Window, QBrush(pix));
    this -> setPalette(p);
    this->setWindowTitle("初始界面");
    ui->setupUi(this);
    int x = 200;
    int y = 200;
    move(x,y);
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setDatabaseName("ids");
    db.setUserName(id.c_str());
    db.setPassword(password.c_str());
    if (!db.open()) {
        errorWindow("连接失败", "无法连接数据库");
        return;
    }
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    QSqlTableModel *model = new QSqlTableModel(ui->tableView);
    ui->tableView->setSelectionMode(QAbstractItemView::NoSelection);

    // 设置表名
    model->setTable("tcp_rules");

    // 选择所有记录
    if (model->select()) {
        // 将模型设置到视图
        ui->tableView->setModel(model);
    }
}

showdatabase::~showdatabase()
{
    delete ui;
}
