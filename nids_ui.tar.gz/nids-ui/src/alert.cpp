#include "alert.h"
#include "ui_alert.h"
#include "attacklog.h"
#include <QFile>
#include <QTextStream>

Alert::Alert(const QString &filePath, QWidget *parent) :
    QDialog(parent), filePath(filePath), ui(new Ui::Alert), watcher(new QFileSystemWatcher(this))
{
    //设置显示背景
    this -> setAutoFillBackground(true);
    QPalette p = this -> palette();
    QPixmap pix(":/photo.png");
    p.setBrush(QPalette::Window, QBrush(pix));
    this -> setPalette(p);
    ui->setupUi(this);
    ui->label_2->setStyleSheet("height: 90px;");
    int x = 200;
    int y = 200;
    move(x,y);

    // 初始化文件监视器并添加文件路径
    watcher->addPath(filePath);
    connect(watcher, &QFileSystemWatcher::fileChanged, this, &Alert::updateTextFileContent);


    // 初始加载文件内容
    updateTextFileContent();
}
Alert::~Alert()
{
    delete ui;
    delete watcher;
}

void Alert::updateTextFileContent()
{
    QFile file(filePath);
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QTextStream in(&file);
        QString text = in.readAll();

        ui->label_2->setText(text);
        file.close();
    } else {
        ui->label_2->setText("无法打开文件: " + filePath);
    }
}

void Alert::on_pushButton_clicked()
{

    attacklog *config = new attacklog;

    config->show();
    config->raise();

}
