#include "menu.h"
#include "alert.h"
#include "ui_menu.h"
#include "auxiliary.h"
#include "CaptureThread.h"
#include <pcap.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdarg.h>
#include "acsm.h"
#include <sys/time.h>
#include <mysql/mysql.h>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QApplication>
#include <QMessageBox>
#include <QString>
#include <QDialog>
#include <QVBoxLayout>
#include <QLabel>
#include <QDesktopWidget>
#include <QVBoxLayout>
#include "showdatabase.h"
#include "showpattern.h"
#include <string>
using namespace std;
#include <QDebug>

// #include <base64.h>

#include <QThread>

typedef struct { //ip头格式
    u_char version:4;
    u_char header_len:4;
    u_char tos:8;
    u_int16_t total_len:16;
    u_int16_t ident:16;
    u_char flags:8;
    u_char fragment:8;
    u_char ttl:8;
    u_char proto:8;
    u_int16_t checksum;
    u_char sourceIP[4];
    u_char destIP[4];
}IPHEADER;

// 定义用于保存重组后数据包的结构体
typedef struct POnepOnepacket {
    u_char src_ip[4];
    u_char dest_ip[4];
    char *packetcontent;
    int contentlen;
    int is_last_frag;
    int offset;
    u_int16_t id;
    int totallen;
    char src[10];
    char des[10];
} POnepOnepacket;

typedef struct Packetinfo2{
    u_char src_ip[4];
    u_char dest_ip[4];
    char *packetcontent;
    int contentlen;
    char src[10];
    char des[10];
}PACKETINFO2;

#define MAX_FRAG 1024
POnepOnepacket packets[MAX_FRAG];
int frag_num = 0;

typedef struct ATTACKPATTERN{
    char attackdes[256];
    char patterncontent[5000];
    int patternlen;
    char src[10];
    char des[10];
    struct ATTACKPATTERN *next;
}ATTACKPATTERN;

ATTACKPATTERN* pPatternHeader;//全局变量，保存攻击模式链表头
int minpattern_len;    //最短模式的长度


pcap_t *phandle;

int count_alert = 0;
int count_last = 0;

// 声明二维数组指针
int **suffix;
bool **prefix;
int **modelStrIndex;
acsm_context_t  *ctx;

extern string id;
extern string password;
extern int rules;
extern int al;

void acsm_free(acsm_context_t *ctx);

int acsm_add_pattern(acsm_context_t *ctx, u_char *string, size_t len, int pattern_id);
int acsm_compile(acsm_context_t *ctx);

char *url_decode(char *src_string);


int readpattern(char *patternfile){
    FILE *file;
    char linebuffer[256];

    file = fopen(patternfile,"r");
    if ( file == NULL) {
        printf("Cann't open the pattern file! Please check it and try again! \n");
        return 1;
    }
    bzero(linebuffer,256);

    while(fgets(linebuffer,255,file)){
        ATTACKPATTERN *pOnepattern;
        int deslen;
        char *pchar;
        pchar = strchr(linebuffer,'#');
        if (pchar == NULL)
            continue;
        pOnepattern = (ATTACKPATTERN *)malloc(sizeof(ATTACKPATTERN) + 1);
        deslen = pchar - linebuffer;
        pOnepattern->patternlen = strlen(linebuffer) - deslen -1 -1 ;
        pchar ++;
        memcpy(pOnepattern->attackdes, linebuffer, deslen);
        memcpy(pOnepattern->patterncontent, pchar, pOnepattern->patternlen);
        memcpy(pOnepattern->src, "any", 3);
        memcpy(pOnepattern->des, "any", 3);
        if (pOnepattern->patternlen < minpattern_len)
            minpattern_len = pOnepattern->patternlen;
        pOnepattern->next = NULL;

        if (pPatternHeader == NULL)
            pPatternHeader = pOnepattern;
        else{
            pOnepattern->next = pPatternHeader;
            pPatternHeader = pOnepattern;
        }
        bzero(linebuffer,256);
        //进行解码
                char *decoded_content = url_decode(pOnepattern->patterncontent);
                memcpy(pOnepattern->patterncontent, decoded_content, strlen(decoded_content));
                pOnepattern->patterncontent[strlen(decoded_content)] = '\0';
                pOnepattern->patternlen = strlen(pOnepattern->patterncontent);
    }
    if (pPatternHeader == NULL)
        return 1;
    return 0;
}


int readpattern_sql(){
    // 创建并打开数据库连接
        QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
        db.setHostName("localhost");
        db.setDatabaseName("ids");
        db.setUserName(id.c_str());
        db.setPassword(password.c_str());

        if (!db.open()) {
            qDebug() << "Error connecting to database:" << db.lastError().text();
            return 1;
        }

        qDebug() << "Connected to database successfully";

        // 执行查询
        QSqlQuery query;
        if (!query.exec("SELECT * FROM tcp_rules")) {  // 替换为你的表名
            qDebug() << "Error executing query:" << query.lastError().text();
            db.close();
            return 1;
        }

        // 打印查询结果
        while (query.next()) {
            ATTACKPATTERN *pOnepattern;
            pOnepattern = (ATTACKPATTERN *)malloc(sizeof(ATTACKPATTERN) + 1);

            pOnepattern->patternlen = query.value(1).toString().length();
            strcpy(pOnepattern->attackdes, query.value(0).toString().toLatin1().data());
            strcpy(pOnepattern->patterncontent, query.value(1).toString().toLatin1().data());
            strcpy(pOnepattern->src, query.value(2).toString().toLatin1().data());
            strcpy(pOnepattern->des, query.value(3).toString().toLatin1().data());

            if (pOnepattern->patternlen < minpattern_len)
                minpattern_len = pOnepattern->patternlen;

            pOnepattern->next = NULL;

            if (pPatternHeader == NULL)
                pPatternHeader = pOnepattern;
            else {
                ATTACKPATTERN *current = pPatternHeader;
                while (current->next != NULL)
                    current = current->next;
                current->next = pOnepattern;
            }
            //进行解码
                    char *decoded_content = url_decode(pOnepattern->patterncontent);
                    memcpy(pOnepattern->patterncontent, decoded_content, strlen(decoded_content));
                    pOnepattern->patterncontent[strlen(decoded_content)] = '\0';
                    pOnepattern->patternlen = strlen(pOnepattern->patterncontent);
        }

        // 关闭数据库连接
        db.close();

        if (pPatternHeader == NULL)
            return 1;

        return 0;
}

void badCharInit(char modelStr[],int modelStrLen, int modelStrIndex[]) {

    //-1表示该字符在匹配串中没有出现过
    for (int i = 0 ; i < 256 ; i ++) {
        modelStrIndex[i] = -1;
    }
    for (int i = 0 ; i < modelStrLen ; i++) {
        //直接依次存入，出现相同的直接覆盖，
        //保证保存的时候靠后出现的位置
        modelStrIndex[modelStr[i]] = i;
    }
}

//2.好后缀数组的建立,suffix为后缀字符对应前面的位置，prefix存储：是否存在匹配的前缀字串
void generateGS(char patterncontent[], int patternlen, int suffix[], bool prefix[])
{
    int n = patternlen;
    for (int i = 0; i < n - 1; i++)
    {
        suffix[i] = -1;
        prefix[i] = false;
    }

    for (int i = 0; i < n - 1; i++)
    {
        int j = i;//从第一个字符开始遍历，str[j]
        int k = 0;//最后一个字符的变化，对应下面的str[n - 1 - k]
        while (j >= 0 && patterncontent[j] == patterncontent[n - 1 - k])//和最后一个字符对比，相等则倒数第二个
        {
            j--;
            k++;
            suffix[k] = j + 1;//如果k=1，则是一个字符长度的后缀对应匹配位置的值
        }
        if (j == -1)//说明有前缀字符对应
            prefix[k] = true;
    }

}









//登录后的主菜单
Menu::Menu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Menu)
{
    //设置显示背景
    this -> setAutoFillBackground(true);
    QPalette p = this -> palette();
    QPixmap pix(":/photo.png");
    p.setBrush(QPalette::Window, QBrush(pix));
    this -> setPalette(p);

    ui->setupUi(this);
    this->setWindowTitle("攻击检测系统");
    int x = 200;
    int y = 200;
    move(x,y);
    connect(ui->pushButton, &QPushButton::clicked, this, &Menu::startCapture);


        char patternfile[256]="patternfile";  //保存攻击模式文件名
        if(rules==1||rules==2){
            if (readpattern(patternfile))
                exit(0);
        }

        if(rules==1||rules==0){
            if (readpattern_sql()) exit(0);
        }



        if(al==2||(al==0 && rules!=2)){
            ATTACKPATTERN *pOnepattern = pPatternHeader;

            ctx = acsm_alloc(0);
            if (ctx == NULL) {
                fprintf(stderr, "acsm_alloc() error.\n");
                return;
            }
            int pattern_id = 0; // 初始化模式串序号

            while(pOnepattern != NULL) {
                if (acsm_add_pattern(ctx, (u_char *)(pOnepattern ->patterncontent), acsm_strlen((u_char *)(pOnepattern ->patterncontent)), pattern_id) != 0) {
                    fprintf(stderr, "acsm_add_pattern() with pattern \"%s\" error.\n",
                            (u_char *)(pOnepattern ->patterncontent));
                    return;
                }

                pOnepattern = pOnepattern->next;
                pattern_id++;
            }

            if (acsm_compile(ctx) != 0) {
                fprintf(stderr, "acsm_compile() error.\n");
                return;
            }
        }




        if(al==3||(al==0 && rules==2)){
            ATTACKPATTERN *pOnepattern = pPatternHeader;
            int pattern_len = 0;
            while(pOnepattern != NULL){
                pattern_len++;
                pOnepattern = pOnepattern->next;
            }
            pOnepattern = pPatternHeader;


            // 分配内存空间
            suffix = (int **)malloc(pattern_len * sizeof(int *));
            if (suffix == NULL) {
                printf("Memory allocation failed.\n");
                return;
            }

            // 分配内存空间
            prefix = (bool **)malloc(pattern_len * sizeof(bool *));
            if (prefix == NULL) {
                printf("Memory allocation failed.\n");
                return;
            }

            // 分配内存空间
            modelStrIndex = (int **)malloc(pattern_len * sizeof(int *));
            if (modelStrIndex == NULL) {
                printf("Memory allocation failed.\n");
                return;
            }

            int i=0;
            while(pOnepattern != NULL){
                int m = pOnepattern->patternlen;
                char *pcontent = pOnepattern -> patterncontent;
                suffix[i] = (int *)malloc(m * sizeof(int));
                if (suffix[i] == NULL) {
                    printf("Memory allocation failed.\n");
                    // 释放之前分配的内存
                    for (int j = 0; j < i; j++) {
                        free(suffix[j]);
                    }
                    free(suffix);
                    return;
                }
                prefix[i] = (bool *)malloc(m * sizeof(bool));
                if (prefix[i] == NULL) {
                    printf("Memory allocation failed.\n");
                    // 释放之前分配的内存
                    for (int j = 0; j < i; j++) {
                        free(prefix[j]);
                    }
                    free(prefix);
                    return;
                }
                modelStrIndex[i] = (int *)malloc(256 * sizeof(int));
                if (modelStrIndex[i] == NULL) {
                    printf("Memory allocation failed.\n");
                    // 释放之前分配的内存
                    for (int j = 0; j < i; j++) {
                        free(modelStrIndex[j]);
                    }
                    free(modelStrIndex);
                    return;
                }
                badCharInit(pcontent, m, modelStrIndex[i]);
                generateGS(pcontent, m, suffix[i], prefix[i]);
                pOnepattern = pOnepattern->next;
                i++;
            }
        }


}

class NonModalDialog : public QDialog {
public:
    NonModalDialog(QWidget *parent = nullptr) : QDialog(parent) {
        setWindowTitle("Alert!");
        setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint); // 移除帮助按钮

        QVBoxLayout *layout = new QVBoxLayout(this);
        QLabel *infoLabel = new QLabel("发现攻击！\n你可以点击“查看全部检测日志”按钮查看详细信息", this);
        QPushButton *closeButton = new QPushButton("关闭", this);
        layout->addWidget(infoLabel);
        layout->addWidget(closeButton);

        connect(closeButton, &QPushButton::clicked, this, &QDialog::close);

        // 设置为非模态对话框
        setAttribute(Qt::WA_ShowWithoutActivating);
                // 计算对话框的新位置
                int x = 0;
                int y = 0;
                // 移动对话框到新位置
                move(x, y);
    }
};

void Menu::startCapture()
{

    ("\033[1;34m");
    ("Start to detect intrusion........\n");  //此函数设置过滤器并开始进行数据包的捕捉
    ("\033[0m");
    connect(captureThread, &QThread::finished, this, &Menu::captureFinished);
    ("this\n");

    NonModalDialog *dialog = new NonModalDialog();


    QTimer *timer = new QTimer(this);
    timer->setInterval(1000); // 每1000毫秒检查一次
    connect(timer, &QTimer::timeout, [dialog]() {
        if (count_last != count_alert) {
            dialog->show();
            dialog->raise();
            count_alert=0; // 更新原始变量
        }
    });
    timer->start();

}

void Menu::captureFinished()
{
    // 线程结束时的清理工作
    delete captureThread;
    captureThread = nullptr; // 重置指针
    if(al==2||(al==0 && rules!=2))acsm_free(ctx);

    pcap_close(phandle);
}

Menu::~Menu()
{
    delete ui;
}

void Menu::on_pushButton_2_clicked()
{
    showdatabase *config = new showdatabase;
    config->show();
}


void Menu::on_pushButton_3_clicked()
{
    showpattern *config = new showpattern;
    config->show();
}

void Menu::slot1() {

}


void Menu::on_pushButton_clicked()
{

    Alert *alert = new Alert("attack_alert.txt",this);
    alert->show();

    captureThread = new CaptureThread(this);
    if (!captureThread->isRunning()) {
        captureThread->start();
    }
}

