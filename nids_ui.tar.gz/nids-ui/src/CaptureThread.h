#ifndef CAPTURETHREAD_H
#define CAPTURETHREAD_H
#include <QThread>

class CaptureThread : public QThread
{
    Q_OBJECT

public:
    CaptureThread(QObject *parent = nullptr);

protected:
    void run() override; // 确保虚函数有声明


};
#endif // CAPTURETHREAD_H
